// SettingsScriptlet.cs
//

using System;
using System.Collections;
using System.Html;
using System.Gadgets;

namespace $safeprojectname$ {

    public class SettingsScriptlet {

        private SettingsScriptlet() {
            // TODO: Add initialization code here
        }

        public static void Main(Dictionary arguments) {
            SettingsScriptlet scriptlet = new SettingsScriptlet();
        }
    }
}
