// FlyoutScriptlet.cs
//

using System;
using System.Collections;
using System.Html;
using System.Gadgets;

namespace $safeprojectname$ {

    public class FlyoutScriptlet {

        private FlyoutScriptlet() {
            // TODO: Add initialization code here
        }

        public static void Main(Dictionary arguments) {
            FlyoutScriptlet scriptlet = new FlyoutScriptlet();
        }
    }
}
