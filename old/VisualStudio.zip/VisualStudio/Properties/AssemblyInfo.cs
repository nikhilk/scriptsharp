﻿// AssemblyInfo.cs
// Script#/Tools/VisualStudio
// This source code is subject to terms and conditions of the Apache License, Version 2.0.
//

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ScriptSharp.VisualStudio")]
[assembly: AssemblyDescription("Script# Visual Studio Integration")]
