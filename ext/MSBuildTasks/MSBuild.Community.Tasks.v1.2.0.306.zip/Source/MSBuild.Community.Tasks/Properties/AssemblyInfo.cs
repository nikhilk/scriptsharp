// $Id: AssemblyInfo.cs 102 2006-01-09 18:01:13Z iko $
// Copyright © 2006 Paul Welter

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("MSBuild.Community.Tasks")]
[assembly: AssemblyDescription("MSBuild community tasks library")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCulture("")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("d038566a-1937-478a-b5c5-b79c4afb253d")]

