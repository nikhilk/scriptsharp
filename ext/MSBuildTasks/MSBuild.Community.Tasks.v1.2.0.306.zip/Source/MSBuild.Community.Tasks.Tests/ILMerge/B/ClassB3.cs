// $Id: ClassB3.cs 109 2006-01-15 20:11:29Z iko $
// Copyright � 2006 Ignaz Kohlbecker

using System;

namespace MSBuild.Community.Tasks.Tests.ILMerging
{
	/// <summary>
	/// Public test class for ILMerge.
	/// </summary>
	public class ClassB3
	{
	}
}
