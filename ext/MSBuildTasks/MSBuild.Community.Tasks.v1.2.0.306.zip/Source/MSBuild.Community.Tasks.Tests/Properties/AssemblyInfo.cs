﻿// $Id: AssemblyInfo.cs 102 2006-01-09 18:01:13Z iko $
// Copyright © 2006 Paul Welter

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("MSBuild.Community.Tasks.Tests")]
[assembly: AssemblyDescription("NUnit test suite for the MSBuild community tasks project")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCulture("")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("739e3039-c66c-4679-89d1-d21d35f8dd4e")]
